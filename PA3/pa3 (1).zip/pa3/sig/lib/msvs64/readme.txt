This folder containts 64 bit libraries built with Visual Studio 
