This folder containts 32 bit libraries built with Visual Studio 
